# interactive_qa_dual_ai.py
"""
TEFAS Analysis System - Dual AI Q&A (OpenAI vs Ollama)
Her iki AI'ın da yanıt vermesi için güncellenmiş versiyon
"""

import sys
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from config.config import Config
from analysis.coordinator import AnalysisCoordinator
from analysis.hybrid_fund_selector import HybridFundSelector, HighPerformanceFundAnalyzer

class DualAITefasQA:
    """TEFAS Soru-Cevap Sistemi - OpenAI ve Ollama karşılaştırmalı"""
    
    def __init__(self):
        print("🚀 TEFAS Analysis Dual AI Q&A System Loading...")
        self.config = Config()
        self.coordinator = AnalysisCoordinator(self.config)
        
        # Aktif fonları yükle
        print("📊 Loading active funds...")
        self.active_funds = self._load_active_funds()
        print(f"✅ Loaded {len(self.active_funds)} active funds")
        
        # AI durumunu kontrol et
        self.ai_status = self._check_ai_availability()
        
    def _load_active_funds(self, max_funds=None, mode="hybrid"):
        """
        Gelişmiş fon yükleme sistemi
        mode: "hybrid" (1-2 dk), "comprehensive" (5-10 dk), "fast" (30 sn)
        """
        
        if mode == "hybrid":
            print("🎯 Hibrit mod: Akıllı örnekleme + Büyük fonlar")
            selector = HybridFundSelector(self.coordinator.db, self.config)
            active_funds, analysis_funds = selector.load_funds_hybrid(
                quick_sample=150,    # 150 temsili fon
                detailed_analysis=30, # 30 detaylı analiz
                include_top=True     # Büyük fonları dahil et
            )
            return analysis_funds
            
        elif mode == "comprehensive":
            print("🚀 Kapsamlı mod: TÜM FONLAR (5-10 dakika)")
            analyzer = HighPerformanceFundAnalyzer(self.coordinator.db, self.config)
            all_results = analyzer.analyze_all_funds_optimized(
                batch_size=100,
                max_workers=8,
                use_bulk_queries=True
            )
            # En iyi 50 fonu döndür
            return all_results.head(50)['fcode'].tolist()
            
        else:  # fast
            print("⚡ Hızlı mod: İlk 50 fon")
            all_funds = self.coordinator.db.get_all_fund_codes()
            return all_funds[:50]
        
    def _check_ai_availability(self):
        """AI sistemlerinin durumunu kontrol et"""
        ai_status = {
            'openai': self.coordinator.ai_analyzer.openai_available,
            'ollama': self.coordinator.ai_analyzer.ollama_available
        }
        
        print(f"\n🤖 AI SİSTEMLERİ DURUMU:")
        print(f"   📱 OpenAI: {'✅ Hazır' if ai_status['openai'] else '❌ Mevcut değil'}")
        print(f"   🦙 Ollama: {'✅ Hazır' if ai_status['ollama'] else '❌ Mevcut değil'}")
        
        if ai_status['openai'] and ai_status['ollama']:
            print("   🎯 Her iki AI de aktif - Karşılaştırmalı analiz mevcut!")
        elif ai_status['openai']:
            print("   🎯 Sadece OpenAI aktif")
        elif ai_status['ollama']:
            print("   🎯 Sadece Ollama aktif")
        else:
            print("   ⚠️ Hiçbir AI sistemi aktif değil")
            
        return ai_status
    
    def answer_question(self, question):
        """Soruya her iki AI ile de cevap ver"""
        question_lower = question.lower()
        
        # Soru tipini tespit et
        if any(word in question_lower for word in ['2025', 'öneri', 'öner', 'recommend', 'suggest']):
            return self._handle_2025_recommendation_dual(question)
        elif any(word in question_lower for word in ['analiz', 'analyze', 'performance']):
            return self._handle_analysis_question_dual(question)
        elif any(word in question_lower for word in ['karşılaştır', 'compare', 'vs']):
            return self._handle_comparison_question(question)
        elif any(word in question_lower for word in ['risk', 'güvenli', 'safe']):
            return self._handle_risk_question(question)
        elif any(word in question_lower for word in ['piyasa', 'market', 'durum']):
            return self._handle_market_question_dual(question)
        elif any(word in question_lower for word in ['ai', 'yapay zeka', 'test']):
            return self._handle_ai_test_question(question)
        else:
            return self._handle_general_question(question)
    
    def _handle_2025_recommendation_dual(self, question):
        """2025 fon önerisi - Her iki AI ile analiz"""
        print("🎯 2025 Fund Recommendation Analysis - Dual AI...")
        
        # Tutar parsing
        import re
        amounts = re.findall(r'\b(\d{5,})\b', question)
        investment_amount = 100000
        if amounts:
            try:
                investment_amount = int(amounts[0])
            except:
                pass
        
        # Risk toleransını tespit et
        risk_tolerance = "moderate"
        if any(word in question.lower() for word in ['güvenli', 'safe', 'conservative']):
            risk_tolerance = "conservative"
        elif any(word in question.lower() for word in ['agresif', 'aggressive', 'risk']):
            risk_tolerance = "aggressive"
        
        print(f"📊 Analysis Parameters:")
        print(f"   Risk Tolerance: {risk_tolerance}")
        print(f"   Investment Amount: {investment_amount:,.0f} TL")
        
        # Veritabanı analizi (önceki kodla aynı)
        analysis_results = []
        test_funds = self.active_funds[:10]
        
        print(f"\n🔍 Analyzing {len(test_funds)} funds...")
        
        for i, fcode in enumerate(test_funds):
            try:
                print(f"   [{i+1}/{len(test_funds)}] {fcode}...", end='')
                
                data = self.coordinator.db.get_fund_price_history(fcode, 60)
                
                if len(data) >= 20:
                    prices = data.set_index('pdate')['price'].sort_index()
                    returns = prices.pct_change().dropna()
                    
                    # Basit metrikler
                    total_return = (prices.iloc[-1] / prices.iloc[0] - 1) * 100
                    annual_return = total_return * (252 / len(prices))
                    volatility = returns.std() * np.sqrt(252) * 100
                    sharpe = (annual_return - 15) / volatility if volatility > 0 else 0
                    win_rate = (returns > 0).sum() / len(returns) * 100
                    
                    # 2025 skorunu hesapla
                    score = self._calculate_2025_score(annual_return, volatility, sharpe, win_rate, risk_tolerance)
                    
                    analysis_results.append({
                        'fund_code': fcode,
                        'annual_return': annual_return,
                        'volatility': volatility,
                        'sharpe_ratio': sharpe,
                        'win_rate': win_rate,
                        'score_2025': score,
                        'current_price': prices.iloc[-1]
                    })
                    
                    print(f" ✅ (Score: {score:.1f})")
                else:
                    print(" ❌")
                    
            except Exception as e:
                print(f" ❌")
                continue
        
        if not analysis_results:
            return "❌ Analiz için yeterli veri bulunamadı."
        
        # Sonuçları sırala
        df = pd.DataFrame(analysis_results)
        df = df.sort_values('score_2025', ascending=False)
        
        # Raporu oluştur
        response = f"\n🎯 2025 YIL SONU FON ÖNERİSİ RAPORU (DUAL AI)\n"
        response += f"{'='*55}\n\n"
        
        response += f"📊 ANALİZ PARAMETRELERİ:\n"
        response += f"   • Risk Toleransı: {risk_tolerance.upper()}\n"
        response += f"   • Yatırım Tutarı: {investment_amount:,.0f} TL\n"
        response += f"   • Analiz Edilen Fon: {len(df)}\n\n"
        
        # VERİTABANI ANALİZİ SONUÇLARI
        response += f"📈 VERİTABANI ANALİZİ - EN İYİ 5 FON:\n"
        top_5 = df.head(5)
        
        for i, (_, fund) in enumerate(top_5.iterrows(), 1):
            response += f"\n{i}. {fund['fund_code']} (2025 Skoru: {fund['score_2025']:.1f}/100)\n"
            response += f"   📊 Beklenen Yıllık Getiri: %{fund['annual_return']:.1f}\n"
            response += f"   📉 Risk (Volatilite): %{fund['volatility']:.1f}\n"
            response += f"   ⚡ Sharpe Oranı: {fund['sharpe_ratio']:.3f}\n"
            response += f"   🎯 Kazanma Oranı: %{fund['win_rate']:.1f}\n"
            response += f"   💰 Güncel Fiyat: {fund['current_price']:.4f} TL\n"
        
        # PORTFÖY ÖNERİSİ
        response += f"\n💼 2025 PORTFÖY ÖNERİSİ ({investment_amount:,.0f} TL):\n"
        
        if len(top_5) >= 3:
            # Risk toleransına göre ağırlık dağılımı
            if risk_tolerance == "conservative":
                weights = [0.4, 0.3, 0.2, 0.1, 0.0][:len(top_5)]
            elif risk_tolerance == "aggressive":
                weights = [0.35, 0.25, 0.2, 0.15, 0.05][:len(top_5)]
            else:  # moderate
                weights = [0.35, 0.25, 0.2, 0.15, 0.05][:len(top_5)]
            
            # Normalize weights
            weights = weights[:len(top_5)]
            weights = [w/sum(weights) for w in weights]
            
            portfolio_return = 0
            
            for i, ((_, fund), weight) in enumerate(zip(top_5.iterrows(), weights)):
                amount = investment_amount * weight
                portfolio_return += fund['annual_return'] * weight
                
                response += f"   {fund['fund_code']}: %{weight*100:.0f} ({amount:,.0f} TL)\n"
                response += f"      Beklenen Katkı: %{fund['annual_return']*weight:.1f}\n"
            
            response += f"\n📊 PORTFÖY BEKLENTİLERİ:\n"
            response += f"   📈 Beklenen Yıllık Getiri: %{portfolio_return:.1f}\n"
        
        # ÇİFT AI ANALİZİ - HER İKİSİNİ DE ÇALIŞTIR
        response += f"\n🤖 ÇİFT AI YORUMLARI:\n"
        response += f"{'='*25}\n"
        
        # AI prompt hazırla
        ai_prompt = f"""
        2025 yılı için TEFAS fon analizi sonuçları:
        
        En iyi 3 fon: {', '.join(top_5.head(3)['fund_code'].tolist())}
        Ortalama beklenen getiri: %{top_5.head(3)['annual_return'].mean():.1f}
        Risk toleransı: {risk_tolerance}
        Yatırım tutarı: {investment_amount:,.0f} TL
        
        Bu sonuçlara dayanarak 2025 için kısa ve özlü yorum yap (maksimum 300 kelime).
        """
        
        # OpenAI Analizi
        if self.ai_status['openai']:
            print("🤖 OpenAI analizi yapılıyor...")
            try:
                openai_response = self.coordinator.ai_analyzer.query_openai(
                    ai_prompt, 
                    "Sen TEFAS uzmanı bir finansal analistsin."
                )
                response += f"\n📱 OpenAI (GPT) Değerlendirmesi:\n"
                response += f"   {openai_response}\n"
            except Exception as e:
                response += f"\n📱 OpenAI Değerlendirmesi:\n"
                response += f"   ❌ Analiz alınamadı: {str(e)[:100]}\n"
        else:
            response += f"\n📱 OpenAI: ❌ Mevcut değil\n"
        
        # Ollama Analizi
        if self.ai_status['ollama']:
            print("🦙 Ollama analizi yapılıyor...")
            try:
                ollama_response = self.coordinator.ai_analyzer.query_ollama(
                    ai_prompt,
                    "Sen TEFAS uzmanı bir finansal analistsin."
                )
                response += f"\n🦙 Ollama (Mistral) Değerlendirmesi:\n"
                response += f"   {ollama_response}\n"
            except Exception as e:
                response += f"\n🦙 Ollama Değerlendirmesi:\n"
                response += f"   ❌ Analiz alınamadı: {str(e)[:100]}\n"
        else:
            response += f"\n🦙 Ollama: ❌ Mevcut değil\n"
        
        # AI Karşılaştırma Özeti
        if self.ai_status['openai'] and self.ai_status['ollama']:
            response += f"\n🎯 AI KARŞILAŞTIRMASI:\n"
            response += f"   Her iki AI de analiz tamamlandı. Yukarıdaki yorumları karşılaştırabilirsiniz.\n"
            response += f"   OpenAI genellikle daha detaylı, Ollama daha özlü yorumlar yapar.\n"
        
        # RİSK UYARILARI
        response += f"\n⚠️ 2025 RİSK UYARILARI:\n"
        response += f"   • Geçmiş performans gelecek getiriyi garanti etmez\n"
        response += f"   • Türkiye ekonomik göstergelerini takip edin\n"
        response += f"   • Portföyü çeyrek yıllık gözden geçirin\n"
        response += f"   • AI öneriler bilgilendirme amaçlıdır, yatırım tavsiyesi değildir\n"
        
        response += f"\n✅ Dual AI analizi tamamlandı: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        
        return response
    
    def _handle_analysis_question_dual(self, question):
        """Tek fon analizi - Her iki AI ile"""
        words = question.upper().split()
        fund_code = None
        
        for word in words:
            if len(word) == 3 and word.isalpha():
                if word in self.active_funds:
                    fund_code = word
                    break
        
        if not fund_code:
            return f"❌ Geçerli bir fon kodu bulunamadı. Örnek: 'AKB fonunu analiz et'\nMevcut fonlar: {', '.join(self.active_funds[:10])}..."
        
        try:
            print(f"🔍 {fund_code} fonu dual AI analizi...")
            
            # Veritabanı analizi
            data = self.coordinator.db.get_fund_price_history(fund_code, 100)
            
            if data.empty:
                return f"❌ {fund_code} için veri bulunamadı"
            
            prices = data.set_index('pdate')['price'].sort_index()
            returns = prices.pct_change().dropna()
            
            # Temel metrikler
            total_return = (prices.iloc[-1] / prices.iloc[0] - 1) * 100
            annual_return = total_return * (252 / len(prices))
            volatility = returns.std() * np.sqrt(252) * 100
            sharpe = (annual_return - 15) / volatility if volatility > 0 else 0
            win_rate = (returns > 0).sum() / len(returns) * 100
            
            # Sonuçları formatla
            response = f"\n📊 {fund_code} FONU DUAL AI ANALİZ RAPORU\n"
            response += f"{'='*45}\n\n"
            
            response += f"💰 TEMEL VERİLER:\n"
            response += f"   Güncel Fiyat: {prices.iloc[-1]:.4f} TL\n"
            response += f"   Son {len(prices)} Gün Getiri: %{total_return:.2f}\n"
            response += f"   Yıllık Getiri (Tahmini): %{annual_return:.1f}\n"
            response += f"   Volatilite: %{volatility:.1f}\n"
            response += f"   Sharpe Oranı: {sharpe:.3f}\n"
            response += f"   Kazanma Oranı: %{win_rate:.1f}\n\n"
            
            # AI Analizleri
            ai_prompt = f"""
            {fund_code} fonu analiz verileri:
            
            Güncel Fiyat: {prices.iloc[-1]:.4f} TL
            Yıllık Getiri: %{annual_return:.1f}
            Volatilite: %{volatility:.1f}
            Sharpe Oranı: {sharpe:.3f}
            Kazanma Oranı: %{win_rate:.1f}
            Veri Periyodu: {len(prices)} gün
            
            Bu verilere dayanarak fonun durumunu değerlendir ve yatırım önerisi ver.
            """
            
            response += f"🤖 DUAL AI DEĞERLENDİRMESİ:\n"
            response += f"{'='*30}\n"
            
            # OpenAI
            if self.ai_status['openai']:
                try:
                    openai_analysis = self.coordinator.ai_analyzer.query_openai(
                        ai_prompt,
                        "Sen TEFAS fonu uzmanısın."
                    )
                    response += f"\n📱 OpenAI Analizi:\n{openai_analysis}\n"
                except Exception as e:
                    response += f"\n📱 OpenAI: ❌ Analiz alınamadı\n"
            
            # Ollama
            if self.ai_status['ollama']:
                try:
                    ollama_analysis = self.coordinator.ai_analyzer.query_ollama(
                        ai_prompt,
                        "Sen TEFAS fonu uzmanısın."
                    )
                    response += f"\n🦙 Ollama Analizi:\n{ollama_analysis}\n"
                except Exception as e:
                    response += f"\n🦙 Ollama: ❌ Analiz alınamadı\n"
            
            response += f"\n✅ Analiz tamamlandı: {datetime.now().strftime('%H:%M:%S')}\n"
            
            return response
            
        except Exception as e:
            return f"❌ Analiz hatası: {e}"
    
    def _handle_market_question_dual(self, question):
        """Piyasa durumu - Her iki AI ile"""
        print("📊 Dual AI piyasa durumu analiz ediliyor...")
        
        try:
            # Son 10 günün verilerini analiz et
            market_data = []
            
            for fcode in self.active_funds[:20]:
                try:
                    data = self.coordinator.db.get_fund_price_history(fcode, 10)
                    if not data.empty:
                        prices = data['price']
                        recent_return = (prices.iloc[-1] / prices.iloc[0] - 1) * 100
                        market_data.append(recent_return)
                except:
                    continue
            
            if market_data:
                avg_return = np.mean(market_data)
                positive_funds = sum(1 for r in market_data if r > 0)
                total_funds = len(market_data)
                
                response = f"\n📈 DUAL AI PİYASA DURUMU RAPORU\n"
                response += f"{'='*35}\n\n"
                
                response += f"📊 SON 10 GÜN VERİLERİ:\n"
                response += f"   Analiz Edilen Fon: {total_funds}\n"
                response += f"   Ortalama Getiri: %{avg_return:.2f}\n"
                response += f"   Pozitif Performans: {positive_funds}/{total_funds} (%{positive_funds/total_funds*100:.1f})\n\n"
                
                # Piyasa durumu
                if avg_return > 2:
                    mood = "🟢 ÇOK POZİTİF"
                elif avg_return > 0:
                    mood = "🟡 POZİTİF"
                elif avg_return > -2:
                    mood = "🟠 NÖTR"
                else:
                    mood = "🔴 NEGATİF"
                
                response += f"🌡️ PİYASA DUYARLILIĞI: {mood}\n\n"
                
                # AI yorumları
                market_prompt = f"""
                TEFAS piyasa durumu:
                
                Son 10 gün ortalama getiri: %{avg_return:.2f}
                Pozitif performans oranı: %{positive_funds/total_funds*100:.1f}
                Analiz edilen fon sayısı: {total_funds}
                Piyasa durumu: {mood}
                
                Bu verilere dayanarak piyasa durumu ve yatırımcı önerileri hakkında kısa yorum yap.
                """
                
                response += f"🤖 DUAL AI PİYASA YORUMLARI:\n"
                response += f"{'='*30}\n"
                
                # OpenAI yorumu
                if self.ai_status['openai']:
                    try:
                        openai_market = self.coordinator.ai_analyzer.query_openai(
                            market_prompt,
                            "Sen piyasa analisti uzmanısın."
                        )
                        response += f"\n📱 OpenAI Piyasa Yorumu:\n{openai_market}\n"
                    except Exception as e:
                        response += f"\n📱 OpenAI: ❌ Piyasa analizi alınamadı\n"
                
                # Ollama yorumu
                if self.ai_status['ollama']:
                    try:
                        ollama_market = self.coordinator.ai_analyzer.query_ollama(
                            market_prompt,
                            "Sen piyasa analisti uzmanısın."
                        )
                        response += f"\n🦙 Ollama Piyasa Yorumu:\n{ollama_market}\n"
                    except Exception as e:
                        response += f"\n🦙 Ollama: ❌ Piyasa analizi alınamadı\n"
                
                return response
            else:
                return "❌ Piyasa analizi için yeterli veri bulunamadı"
                
        except Exception as e:
            return f"❌ Piyasa analizi hatası: {e}"
    
    def _handle_ai_test_question(self, question):
        """AI test soruları"""
        response = f"\n🧪 AI SİSTEMLERİ TEST RAPORU\n"
        response += f"{'='*30}\n\n"
        
        response += f"📊 DURUM RAPORU:\n"
        response += f"   📱 OpenAI: {'✅ Aktif' if self.ai_status['openai'] else '❌ İnaktif'}\n"
        response += f"   🦙 Ollama: {'✅ Aktif' if self.ai_status['ollama'] else '❌ İnaktif'}\n\n"
        
        # Test prompt'u
        test_prompt = "TEFAS fonları hakkında 2 cümlelik kısa bilgi ver."
        
        response += f"🧪 TEST SONUÇLARI:\n"
        
        # OpenAI test
        if self.ai_status['openai']:
            try:
                openai_test = self.coordinator.ai_analyzer.query_openai(test_prompt)
                response += f"\n📱 OpenAI Test:\n   ✅ Çalışıyor\n   Yanıt: {openai_test[:100]}...\n"
            except Exception as e:
                response += f"\n📱 OpenAI Test:\n   ❌ Hata: {str(e)[:50]}\n"
        else:
            response += f"\n📱 OpenAI Test:\n   ❌ Kullanılamıyor\n"
        
        # Ollama test
        if self.ai_status['ollama']:
            try:
                ollama_test = self.coordinator.ai_analyzer.query_ollama(test_prompt)
                response += f"\n🦙 Ollama Test:\n   ✅ Çalışıyor\n   Yanıt: {ollama_test[:100]}...\n"
            except Exception as e:
                response += f"\n🦙 Ollama Test:\n   ❌ Hata: {str(e)[:50]}\n"
        else:
            response += f"\n🦙 Ollama Test:\n   ❌ Kullanılamıyor\n"
        
        return response
    
    def _calculate_2025_score(self, annual_return, volatility, sharpe, win_rate, risk_tolerance):
        """2025 için özel skorlama"""
        score = 0
        
        # Getiri skoru (0-30)
        return_score = min(max(annual_return, 0) / 30 * 30, 30)
        score += return_score
        
        # Sharpe skoru (0-25)
        sharpe_score = min(max(sharpe, 0) * 10, 25)
        score += sharpe_score
        
        # Risk skoru (0-25)
        if risk_tolerance == "conservative":
            risk_score = max(25 - volatility, 0)
        elif risk_tolerance == "aggressive":
            risk_score = min(volatility / 2, 25)
        else:  # moderate
            risk_score = max(20 - abs(volatility - 20) / 2, 0)
        score += risk_score
        
        # Konsistans skoru (0-20)
        consistency_score = win_rate / 5
        score += consistency_score
        
        return max(min(score, 100), 0)
    
    def _handle_comparison_question(self, question):
        """Fon karşılaştırması (önceki kodla aynı)"""
        words = question.upper().split()
        fund_codes = []
        
        for word in words:
            if len(word) == 3 and word.isalpha():
                if word in self.active_funds:
                    fund_codes.append(word)
        
        if len(fund_codes) < 2:
            return f"❌ Karşılaştırma için en az 2 fon kodu gerekli. Örnek: 'AKB ve YAS karşılaştır'"
        
        try:
            comparison_data = []
            
            for fcode in fund_codes:
                data = self.coordinator.db.get_fund_price_history(fcode, 30)
                if not data.empty:
                    prices = data['price']
                    return_30d = (prices.iloc[-1] / prices.iloc[0] - 1) * 100
                    
                    comparison_data.append({
                        'fund': fcode,
                        'return_30d': return_30d,
                        'current_price': prices.iloc[-1]
                    })
            
            if not comparison_data:
                return "❌ Karşılaştırma için veri bulunamadı"
            
            response = f"\n⚖️ FON KARŞILAŞTIRMASI\n"
            response += f"{'='*22}\n\n"
            
            for fund_data in comparison_data:
                response += f"📊 {fund_data['fund']}:\n"
                response += f"   30 Gün Getiri: %{fund_data['return_30d']:.2f}\n"
                response += f"   Güncel Fiyat: {fund_data['current_price']:.4f} TL\n\n"
            
            # Kazanan
            best = max(comparison_data, key=lambda x: x['return_30d'])
            response += f"🏆 En İyi Performans: {best['fund']} (%{best['return_30d']:.2f})\n"
            
            return response
            
        except Exception as e:
            return f"❌ Karşılaştırma hatası: {e}"
    
    def _handle_risk_question(self, question):
        """Risk soruları (önceki kodla aynı)"""
        response = f"\n🛡️ RİSK ANALİZİ VE GÜVENLİ YATIRIM\n"
        response += f"{'='*35}\n\n"
        
        # Düşük riskli fonları bul
        low_risk_funds = []
        
        for fcode in self.active_funds[:15]:
            try:
                data = self.coordinator.db.get_fund_price_history(fcode, 60)
                if not data.empty:
                    returns = data['price'].pct_change().dropna()
                    volatility = returns.std() * 100
                    
                    if volatility < 15:  # %15'ten düşük volatilite
                        low_risk_funds.append({
                            'fund': fcode,
                            'volatility': volatility,
                            'return': (data['price'].iloc[-1] / data['price'].iloc[0] - 1) * 100
                        })
            except:
                continue
        
        if low_risk_funds:
            df = pd.DataFrame(low_risk_funds).sort_values('volatility')
            
            response += f"🛡️ DÜŞÜK RİSKLİ FONLAR:\n"
            for _, fund in df.head(5).iterrows():
                response += f"   {fund['fund']}: Risk %{fund['volatility']:.1f}, Getiri %{fund['return']:.1f}\n"
        
        response += f"\n📋 RİSK YÖNETİMİ PRİNSİPLERİ:\n"
        response += f"   • Portföyünüzü diversifiye edin\n"
        response += f"   • Risk toleransınızı bilin\n"
        response += f"   • Acil fon ayırın (6-12 aylık gider)\n"
        response += f"   • Düzenli olarak rebalancing yapın\n"
        response += f"   • Uzun vadeli düşünün\n"
        
        return response
    
    def _handle_general_question(self, question):
        """Genel sorular"""
        response = f"\n❓ DUAL AI TEFAS ANALİZ SİSTEMİ\n"
        response += f"{'='*35}\n\n"
        
        response += f"🤖 SİSTEM DURUMU:\n"
        response += f"   📱 OpenAI: {'✅ Aktif' if self.ai_status['openai'] else '❌ İnaktif'}\n"
        response += f"   🦙 Ollama: {'✅ Aktif' if self.ai_status['ollama'] else '❌ İnaktif'}\n"
        response += f"   📊 Aktif Fonlar: {len(self.active_funds)}\n"
        response += f"   🗄️ Veritabanı: ✅ Bağlı\n\n"
        
        response += f"📋 DUAL AI SORU TİPLERİ:\n"
        response += f"   • '2025 için hangi fonları önerirsin?' (Her iki AI de yanıt verir)\n"
        response += f"   • 'AKB fonunu analiz et' (Dual AI değerlendirme)\n"
        response += f"   • 'Piyasa durumu nasıl?' (İkili AI yorumu)\n"
        response += f"   • 'AI test' (AI sistemlerini test et)\n"
        response += f"   • 'AKB ve YAS karşılaştır'\n"
        response += f"   • 'Güvenli fonlar neler?'\n\n"
        
        response += f"🎯 DUAL AI AVANTAJLARI:\n"
        response += f"   • OpenAI ve Ollama karşılaştırması\n"
        response += f"   • Farklı AI perspektifleri\n"
        response += f"   • Daha kapsamlı analiz\n"
        response += f"   • AI performans değerlendirmesi\n"
        
        return response
    
    def run_interactive_session(self):
        """İnteraktif dual AI oturumu"""
        print("\n" + "="*60)
        print("🤖 TEFAS DUAL AI ANALYSIS SYSTEM")
        print("="*60)
        print("🎯 Özellik: Her iki AI (OpenAI + Ollama) aynı anda yanıt verir!")
        print("\n💡 Örnek sorular:")
        print("   • '2025 için 100000 TL ile hangi fonları önerirsin?'")
        print("   • 'AKB fonunu analiz et'")
        print("   • 'Piyasa durumu nasıl?'")
        print("   • 'AI test' (AI sistemlerini test et)")
        print("   • 'AKB ve YAS karşılaştır'")
        print("\n💬 Sorunuzu yazın (çıkmak için 'exit' yazın):")
        print("-" * 60)
        
        while True:
            try:
                question = input("\n🔍 Dual AI Soru: ").strip()
                
                if question.lower() in ['exit', 'çıkış', 'quit', 'q']:
                    print("\n👋 Dual AI Session sona erdi!")
                    break
                
                if not question:
                    continue
                
                print(f"\n🔄 Dual AI işleniyor...")
                answer = self.answer_question(question)
                print(answer)
                
                print("\n" + "-" * 60)
                
            except KeyboardInterrupt:
                print("\n\n👋 Dual AI Session sona erdi!")
                break
            except Exception as e:
                print(f"\n❌ Hata oluştu: {e}")
                continue

def main():
    """Ana fonksiyon"""
    try:
        # Dual AI Q&A sistemini başlat
        qa_system = DualAITefasQA()
        
        # Test modunu kontrol et
        if len(sys.argv) > 1:
            if sys.argv[1] == "--test":
                # AI test modu
                print(qa_system._handle_ai_test_question("AI test"))
            elif sys.argv[1] == "--demo":
                # Demo sorular
                demo_questions = [
                    "2025 için 50000 TL ile hangi fonları önerirsin?",
                    "AI test",
                    "Piyasa durumu nasıl?"
                ]
                
                for i, question in enumerate(demo_questions, 1):
                    print(f"\n[DEMO {i}] {question}")
                    print("-" * 40)
                    answer = qa_system.answer_question(question)
                    # İlk 500 karakter göster
                    preview = answer[:500] + "..." if len(answer) > 500 else answer
                    print(preview)
                    if i < len(demo_questions):
                        input("\nDevam etmek için Enter'a basın...")
            else:
                # Tek soru modu
                question = " ".join(sys.argv[1:])
                answer = qa_system.answer_question(question)
                print(answer)
        else:
            # İnteraktif mod
            qa_system.run_interactive_session()
            
    except Exception as e:
        print(f"❌ Dual AI sistem başlatma hatası: {e}")
        return False
    
    return True

if __name__ == "__main__":
    main()