# database/connection.py - İngilizce mesajlarla
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import QueuePool
import pandas as pd
from typing import Optional, Dict, Any, List
import logging
from config.config import Config

Base = declarative_base()

class DatabaseManager:
    def __init__(self, config: Config):
        self.config = config
        self.engine = None
        self.Session = None
        self.logger = logging.getLogger(__name__)
        self._initialize_connection()
    
    def _initialize_connection(self):
        """Initialize database connection"""
        try:
            self.engine = create_engine(
                self.config.database.connection_string,
                poolclass=QueuePool,
                pool_size=10,
                max_overflow=20,
                pool_pre_ping=True,
                echo=False
            )
            self.Session = sessionmaker(bind=self.engine)
            self.logger.info("Database connection successful")  # İngilizce
        except Exception as e:
            self.logger.error(f"Database connection error: {e}")  # İngilizce
            raise
    
    def execute_query(self, query: str, params: Optional[Dict] = None) -> pd.DataFrame:
        """Execute SQL query and return DataFrame"""
        try:
            with self.engine.connect() as conn:
                result = pd.read_sql(text(query), conn, params=params or {})
            return result
        except Exception as e:
            self.logger.error(f"Query execution error: {e}")  # İngilizce
            raise
    
    # Geri kalan metodlar aynı kalabilir...
    def get_fund_data(self, 
                     fcode: Optional[str] = None,
                     start_date: Optional[str] = None,
                     end_date: Optional[str] = None,
                     limit: Optional[int] = None) -> pd.DataFrame:
        """Get fund data"""
        query = """
        SELECT tf.idtefas, tf.pdate, tf.price, tf.fcode, tf.ftitle, 
               tf.fcapacity, tf.sharecount, tf.investorcount
        FROM tefasfunds tf
        WHERE 1=1
        """
        params = {}
        
        if fcode:
            query += " AND tf.fcode = :fcode"
            params['fcode'] = fcode
            
        if start_date:
            query += " AND tf.pdate >= :start_date"
            params['start_date'] = start_date
            
        if end_date:
            query += " AND tf.pdate <= :end_date"
            params['end_date'] = end_date
            
        query += " ORDER BY tf.pdate DESC"
        
        if limit:
            query += f" LIMIT {limit}"
            
        return self.execute_query(query, params)
    
    def get_all_fund_codes(self) -> List[str]:
        """List all fund codes"""
        query = "SELECT DISTINCT fcode FROM tefasfunds ORDER BY fcode"
        result = self.execute_query(query)
        return result['fcode'].tolist()
    
    def get_fund_price_history(self, fcode: str, days: int = 252) -> pd.DataFrame:
        """Get fund price history"""
        query = """
        SELECT pdate, price, fcode
        FROM tefasfunds 
        WHERE fcode = :fcode 
        ORDER BY pdate DESC 
        LIMIT :days
        """
        params = {'fcode': fcode, 'days': days}
        result = self.execute_query(query, params)
        result['pdate'] = pd.to_datetime(result['pdate'])
        return result.sort_values('pdate')